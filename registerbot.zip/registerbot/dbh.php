<?php

$conn = mysqli_connect("localhost", "wcccfonl_wcccf", "*7#jOSEeV7u+", "wcccfonl_wcccf");
if (!$conn) {
	die("Connection failed: ".mysqli_connect_error()); 
}
